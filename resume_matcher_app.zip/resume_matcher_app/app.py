import os
import re
import ast
import json
from pathlib import Path

import joblib
import pandas as pd
import streamlit as st

try:
    from groq import Groq
except Exception:
    Groq = None


# -------------------------
# PAGE SETUP
# -------------------------
st.set_page_config(
    page_title="Resume Matcher",
    page_icon="📄",
    layout="wide"
)

st.title("📄 Resume-to-Job Matcher")
st.caption("Upload a resume and a job description to get a match score, matched skills, missing skills, and tailored feedback.")


# -------------------------
# PATHS / CONFIG
# -------------------------
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "resume_job_matcher_model.pkl"
TRAINING_CSV_PATH = BASE_DIR / "training_pairs_debug.csv"
SKILLS_PATH = BASE_DIR / "skills.txt"
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")


# -------------------------
# HELPERS
# -------------------------
def clean_text(text: str) -> str:
    text = str(text or "").lower()
    text = re.sub(r"[^a-zA-Z0-9\s\+\#\.\-/]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def load_skill_dictionary(file_path: Path) -> list[str]:
    if not file_path.exists():
        return []

    raw = file_path.read_text(encoding="utf-8", errors="ignore").lower()
    parts = re.split(r"[\n,]+", raw)

    skills = []
    seen = set()
    for part in parts:
        skill = part.strip()
        if skill and skill not in seen:
            seen.add(skill)
            skills.append(skill)
    return skills


def extract_skills(text: str, skills_list: list[str]) -> list[str]:
    text = f" {str(text).lower()} "
    found = set()
    for skill in skills_list:
        skill_clean = skill.strip().lower()
        if not skill_clean:
            continue
        pattern = r"(?<!\w)" + re.escape(skill_clean) + r"(?!\w)"
        if re.search(pattern, text):
            found.add(skill_clean)
    return sorted(found)


def safe_parse_list(x):
    if isinstance(x, list):
        return x
    if pd.isna(x):
        return []
    x = str(x).strip()
    if not x:
        return []
    try:
        parsed = ast.literal_eval(x)
        if isinstance(parsed, list):
            return parsed
        return [str(parsed)]
    except Exception:
        return [item.strip().strip("'").strip('"') for item in x.strip("[]").split(",") if item.strip()]


@st.cache_resource
def load_model(model_path: Path):
    if not model_path.exists():
        raise FileNotFoundError(
            "Missing resume_job_matcher_model.pkl. Put the trained model in the same folder as app.py."
        )
    return joblib.load(model_path)


@st.cache_data
def load_training_df(csv_path: Path) -> pd.DataFrame:
    if not csv_path.exists():
        return pd.DataFrame()
    df = pd.read_csv(csv_path)
    if "matched_skills" in df.columns:
        df["matched_skills"] = df["matched_skills"].apply(safe_parse_list)
    if "missing_skills" in df.columns:
        df["missing_skills"] = df["missing_skills"].apply(safe_parse_list)
    return df


@st.cache_data
def load_skills(skills_path: Path) -> list[str]:
    return load_skill_dictionary(skills_path)


model = load_model(MODEL_PATH)
training_df = load_training_df(TRAINING_CSV_PATH)
skills_list = load_skills(SKILLS_PATH)


def predict_match_score(resume_text: str, job_text: str) -> tuple[int, float]:
    combined = "resume: " + clean_text(resume_text) + " job: " + clean_text(job_text)
    pred = model.predict([combined])[0]
    prob = model.predict_proba([combined])[0][1]
    return int(pred), float(prob)


def nearest_examples(resume_text: str, job_text: str, top_n: int = 3) -> pd.DataFrame:
    if training_df.empty or "combined_text" not in training_df.columns:
        return pd.DataFrame()

    combined = "resume: " + clean_text(resume_text) + " job: " + clean_text(job_text)
    tfidf = model.named_steps["tfidf"]
    matrix = tfidf.transform(training_df["combined_text"].fillna("").tolist() + [combined])
    from sklearn.metrics.pairwise import cosine_similarity
    sims = cosine_similarity(matrix[-1], matrix[:-1]).flatten()
    out = training_df.copy()
    out["example_similarity"] = sims
    cols = [c for c in [
        "resume_file", "job_file", "similarity", "label", "matched_skills", "missing_skills", "example_similarity"
    ] if c in out.columns]
    return out.sort_values("example_similarity", ascending=False)[cols].head(top_n)


def build_prompt(resume_text: str, job_text: str, score: float, matched_skills: list[str], missing_skills: list[str]) -> str:
    matched_skills_text = ", ".join(matched_skills) if matched_skills else "None identified"
    missing_skills_text = ", ".join(missing_skills[:15]) if missing_skills else "None identified"

    return f"""
You are an expert resume optimizer and career coach.

Analyze how well this resume matches the job.

MATCH SCORE: {round(score * 100, 2)}%

MATCHED SKILLS:
{matched_skills_text}

MISSING SKILLS:
{missing_skills_text}

----------------------
RESUME:
{str(resume_text)[:5000]}

----------------------
JOB DESCRIPTION:
{str(job_text)[:5000]}

----------------------

Provide:
1. Overall fit assessment (2-3 sentences)
2. Top 3 strengths of the candidate
3. Top 3 gaps or weaknesses
4. 5 keywords the candidate should add if truthful
5. 3 rewritten resume bullet points tailored to the job

Be specific, concise, and realistic. Do not invent experience.
"""


def fallback_feedback(score: float, matched_skills: list[str], missing_skills: list[str]) -> str:
    score_pct = round(score * 100, 1)
    strengths = matched_skills[:3] if matched_skills else []
    gaps = missing_skills[:3] if missing_skills else []
    keywords = missing_skills[:5] if missing_skills else []

    lines = [
        f"Overall fit assessment: This resume appears to be a {('strong' if score_pct >= 70 else 'moderate' if score_pct >= 45 else 'low')} fit for the role based on the trained model, with a match score of {score_pct}%. The strongest overlap comes from the skills already present in both the resume and job description.",
        "",
        "Top 3 strengths:",
    ]
    if strengths:
        lines.extend([f"- {s}" for s in strengths])
    else:
        lines.append("- No clear matched skills were extracted from the uploaded text.")

    lines.extend(["", "Top 3 gaps or weaknesses:"])
    if gaps:
        lines.extend([f"- {g}" for g in gaps])
    else:
        lines.append("- No major missing skills were extracted from the uploaded text.")

    lines.extend(["", "5 keywords to add if truthful:"])
    if keywords:
        lines.extend([f"- {k}" for k in keywords])
    else:
        lines.append("- Add more role-specific skills and tools from the job description where accurate.")

    lines.extend([
        "",
        "3 rewritten resume bullet points tailored to the job:",
        "- Tailored bullet 1: Highlight measurable results, tools used, and job-relevant responsibilities from your real experience.",
        "- Tailored bullet 2: Emphasize project ownership, collaboration, and any technologies or processes named in the job posting that you truly used.",
        "- Tailored bullet 3: Reword one existing bullet to mirror the job description language while keeping it honest and specific.",
    ])
    return "\n".join(lines)


def groq_feedback(resume_text: str, job_text: str, score: float, matched_skills: list[str], missing_skills: list[str]) -> str:
    if not GROQ_API_KEY or Groq is None:
        return fallback_feedback(score, matched_skills, missing_skills)

    client = Groq(api_key=GROQ_API_KEY)
    prompt = build_prompt(resume_text, job_text, score, matched_skills, missing_skills)
    response = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=[
            {"role": "system", "content": "You are a resume optimization assistant."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.3,
    )
    return response.choices[0].message.content


def read_uploaded_file(uploaded_file) -> str:
    if uploaded_file is None:
        return ""
    raw = uploaded_file.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        try:
            return raw.decode("latin-1")
        except Exception:
            return ""


# -------------------------
# SIDEBAR
# -------------------------
with st.sidebar:
    st.header("App setup")
    st.write("This app expects these files in the same folder:")
    st.code("resume_job_matcher_model.pkl\ntraining_pairs_debug.csv\nskills.txt")
    st.write("Optional environment variable for AI feedback:")
    st.code("GROQ_API_KEY=your_key_here")

    status = {
        "model": MODEL_PATH.exists(),
        "training csv": TRAINING_CSV_PATH.exists(),
        "skills": SKILLS_PATH.exists(),
        "groq": bool(GROQ_API_KEY),
    }
    st.json(status)


# -------------------------
# INPUTS
# -------------------------
col1, col2 = st.columns(2)

with col1:
    st.subheader("Resume")
    resume_upload = st.file_uploader("Upload resume (.txt)", type=["txt"], key="resume")
    resume_text_area = st.text_area("Or paste resume text", height=350, placeholder="Paste resume text here...")

with col2:
    st.subheader("Job description")
    job_upload = st.file_uploader("Upload job description (.txt)", type=["txt"], key="job")
    job_text_area = st.text_area("Or paste job description", height=350, placeholder="Paste job description here...")

resume_text = read_uploaded_file(resume_upload) if resume_upload else resume_text_area
job_text = read_uploaded_file(job_upload) if job_upload else job_text_area

analyze = st.button("Analyze Match", type="primary", use_container_width=True)


# -------------------------
# OUTPUTS
# -------------------------
if analyze:
    if not resume_text.strip() or not job_text.strip():
        st.error("Please upload or paste both a resume and a job description.")
    else:
        with st.spinner("Scoring match and generating feedback..."):
            pred, score = predict_match_score(resume_text, job_text)
            resume_skills = extract_skills(resume_text, skills_list)
            job_skills = extract_skills(job_text, skills_list)
            matched_skills = sorted(set(resume_skills).intersection(job_skills))
            missing_skills = sorted(set(job_skills) - set(resume_skills))
            feedback = groq_feedback(resume_text, job_text, score, matched_skills, missing_skills)
            examples = nearest_examples(resume_text, job_text, top_n=3)

        score_pct = round(score * 100, 2)
        label_text = "Match" if pred == 1 else "Low Match"

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Match Score", f"{score_pct}%")
        m2.metric("Prediction", label_text)
        m3.metric("Matched Skills", len(matched_skills))
        m4.metric("Missing Skills", len(missing_skills))

        st.progress(min(max(score, 0.0), 1.0))

        a, b = st.columns(2)
        with a:
            st.subheader("Matched skills")
            if matched_skills:
                st.write(", ".join(matched_skills))
            else:
                st.write("No matched skills found from the current dictionary.")

        with b:
            st.subheader("Missing skills")
            if missing_skills:
                st.write(", ".join(missing_skills[:25]))
            else:
                st.write("No missing skills found from the current dictionary.")

        st.subheader("Feedback")
        st.text_area("Model + AI feedback", value=feedback, height=350)

        if not examples.empty:
            st.subheader("Most similar training examples")
            st.dataframe(examples, use_container_width=True)

        payload = {
            "prediction": pred,
            "match_score": score,
            "matched_skills": matched_skills,
            "missing_skills": missing_skills,
            "feedback": feedback,
        }
        st.download_button(
            "Download result as JSON",
            data=json.dumps(payload, indent=2),
            file_name="resume_match_result.json",
            mime="application/json",
            use_container_width=True,
        )
